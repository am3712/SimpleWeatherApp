package com.example.simpleweatherapp.utils

import android.app.Application
import android.app.NotificationManager
import androidx.core.content.ContextCompat
import androidx.work.*
import com.example.simpleweatherapp.R
import com.example.simpleweatherapp.data.local.Alarm
import com.example.simpleweatherapp.data.remote.Alerts
import com.example.simpleweatherapp.worker.AlarmWorker
import com.example.simpleweatherapp.worker.AlertWorker
import timber.log.Timber
import java.util.concurrent.TimeUnit


fun cancelAlertsWorkManager(app: Application) {
    cancelWorkManager(
        app,
        AlertWorker.ALERTS_TAG,
        app.getString(R.string.weather_alerts_channel_id)
    )
}

fun cancelAlarmsWorkManager(app: Application) {
    cancelWorkManager(
        app,
        AlarmWorker.ALARMS_TAG,
        app.getString(R.string.weather_alarms_channel_id)
    )
}

private fun cancelWorkManager(app: Application, tag: String, channelId: String) {
    // cancel work manager for all incoming alerts
    WorkManager.getInstance(app.applicationContext)
        .cancelAllWorkByTag(tag)

    // cancel all current notification
    val notificationManager =
        ContextCompat.getSystemService(
            app.applicationContext,
            NotificationManager::class.java
        ) as NotificationManager
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        notificationManager.deleteNotificationChannel(channelId)
    else
        notificationManager.cancelAll()
}


fun setupRecurringWorkBuilder(alert: Alerts): OneTimeWorkRequest.Builder {
    val data = Data.Builder()
        .putString(AlertWorker.ALERT_EVENT, alert.event)
        .putString(AlertWorker.ALERT_LOCATION, alert.sender_name)
        .putString(AlertWorker.ALERT_DESCRIPTION, alert.description)
        .build()
    val delay = alert.start - System.currentTimeMillis() - AlertWorker.MINUTE_10
    return OneTimeWorkRequestBuilder<AlertWorker>()
        .setInitialDelay(delay, TimeUnit.MILLISECONDS)
        .setInputData(data)
        .addTag(AlertWorker.ALERTS_TAG)
}

fun setupRecurringWorkBuilder(alarm: Alarm): WorkRequest {

    val mapAlarmRepeatable = alarm.repeatDays.map { "${it.dayIndex}" to it.checked }.toMap()

    val data = Data.Builder()
        .putString(AlarmWorker.ALARM_TYPE, alarm.alarmType)
        .putString(AlarmWorker.ALARM_NAME, alarm.alarmName)
        .putLong(AlarmWorker.ALARM_END_TIME, alarm.end)
        .putAll(mapAlarmRepeatable)
        .build()
    val delay = alarm.start - System.currentTimeMillis()

    //check to detect if we setUp Periodic work or on time work
    if (alarm.detectIfPeriodicOrOneTimeWork() > 1) {
        //setup Periodic Work
        Timber.i("Periodic Work")
        return PeriodicWorkRequestBuilder<AlarmWorker>(1, TimeUnit.DAYS)
            .setInputData(data)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .addTag(AlarmWorker.ALARMS_TAG)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build()
            ).build()
    } else {
        Timber.i("one time work -> alarm.start : ${alarm.start}")
        return OneTimeWorkRequestBuilder<AlarmWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(data)
            .addTag(AlarmWorker.ALARMS_TAG)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build()
            ).build()
    }
}


fun setAlertWorker(
    app: Application,
    repeatingRequestBuilder: OneTimeWorkRequest.Builder,
    uniqueName: String
) {
    WorkManager
        .getInstance(app.applicationContext)
        .enqueueUniqueWork(
            uniqueName,
            ExistingWorkPolicy.KEEP,
            repeatingRequestBuilder.build()
        )
}

fun setAlarmWorker(
    app: Application,
    repeatingRequest: WorkRequest,
    uniqueName: String
) {
    when (repeatingRequest) {
        is OneTimeWorkRequest -> WorkManager
            .getInstance(app.applicationContext)
            .enqueueUniqueWork(
                uniqueName,
                ExistingWorkPolicy.REPLACE,
                repeatingRequest
            )

        is PeriodicWorkRequest -> WorkManager
            .getInstance(app.applicationContext)
            .enqueueUniquePeriodicWork(
                uniqueName,
                ExistingPeriodicWorkPolicy.REPLACE,
                repeatingRequest
            )
    }
}

fun addAlarmWorkManager(app: Application, id: Long, alarm: Alarm) {
    Timber.i("addAlarmWorkManager launch")
    val builder = setupRecurringWorkBuilder(alarm)
    setAlarmWorker(app, builder, id.toString())
}


fun Alarm.detectIfPeriodicOrOneTimeWork(): Int {
    var counter = 0
    repeatDays.forEach {
        if (it.checked) {
            counter++
        }
        if (counter > 1)
            return counter
    }
    return counter
}