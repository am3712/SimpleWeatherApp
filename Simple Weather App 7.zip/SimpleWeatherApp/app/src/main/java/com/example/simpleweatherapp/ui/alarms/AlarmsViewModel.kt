package com.example.simpleweatherapp.ui.alarms

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.work.WorkManager
import com.example.simpleweatherapp.data.local.Alarm
import com.example.simpleweatherapp.data.local.getDatabase
import com.example.simpleweatherapp.data.repository.Repository
import com.example.simpleweatherapp.utils.addAlarmWorkManager
import kotlinx.coroutines.launch

class AlarmsViewModel(
    val app: Application
) : AndroidViewModel(app) {

    val repository = Repository(getDatabase(app.applicationContext))

    val alarms = repository.getAlerts()

    fun deleteAlarm(alarm: Alarm) {
        viewModelScope.launch {
            cancelAlarm(alarm.alarmId.toString())
            repository.deleteAlarm(alarm)
        }
    }

    private fun cancelAlarm(alarmId: String) {
        WorkManager.getInstance(app.applicationContext).cancelUniqueWork(alarmId)
    }

    fun startStopAlarm(alarm: Alarm) {
        viewModelScope.launch {
            if (alarm.isActive) {
                cancelAlarm(alarm.alarmId.toString())
                repository.addAlarm(
                    Alarm(
                        alarmId = alarm.alarmId,
                        alarmName = alarm.alarmName,
                        start = alarm.start,
                        end = alarm.end,
                        alarmType = alarm.alarmType,
                        repeatDays = alarm.repeatDays,
                        isActive = false
                    )
                )
            } else {
                addAlarmWorkManager(app, alarm.alarmId, alarm)
                repository.addAlarm(
                    Alarm(
                        alarmId = alarm.alarmId,
                        alarmName = alarm.alarmName,
                        start = alarm.start,
                        end = alarm.end,
                        alarmType = alarm.alarmType,
                        repeatDays = alarm.repeatDays,
                        isActive = true
                    )
                )
            }
        }
    }
}