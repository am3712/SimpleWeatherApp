package com.example.simpleweatherapp.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING,
    CLEAR
}