package com.example.simpleweatherapp.data.remote

object Constant {
    const val BASE_URL = "https://api.openweathermap.org/"
    const val WEATHER_PATH = "data/2.5/onecall"
    const val APP_ID = "d6050a821acff3e836b7b117ffa2a859"
}