package com.example.simpleweatherapp.worker

import android.app.NotificationManager
import android.content.Context
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.simpleweatherapp.R
import com.example.simpleweatherapp.utils.sendNotification
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class AlertWorker(appContext: Context, params: WorkerParameters) :
    Worker(appContext, params) {

    companion object {

        const val ALERT_EVENT = "AlertEvent"
        const val ALERT_DESCRIPTION = "AlertDescription"
        const val ALERT_LOCATION = "AlertLocation"
        const val ALERTS_TAG = "AlertsTag"
        const val MINUTE_10 = 600000L

    }

    override fun doWork(): Result {
        return try {
            val alertEvent = inputData.getString(ALERT_EVENT) ?: return Result.failure()
            val alertDescription = inputData.getString(ALERT_DESCRIPTION) ?: return Result.failure()
            val alertLocation = inputData.getString(ALERT_LOCATION) ?: return Result.failure()


            // sendNotification
            val notificationManager = ContextCompat.getSystemService(
                applicationContext,
                NotificationManager::class.java
            ) as NotificationManager

            notificationManager.sendNotification(
                alertEvent,
                alertLocation,
                alertDescription,
                applicationContext.getString(R.string.weather_alerts_channel_id),
                applicationContext
            )
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }
}


