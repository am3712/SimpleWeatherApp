package com.example.simpleweatherapp.utils

import android.annotation.SuppressLint
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.databinding.BindingAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.simpleweatherapp.R
import com.example.simpleweatherapp.data.local.Alarm
import com.example.simpleweatherapp.data.local.City
import com.example.simpleweatherapp.data.local.Day
import com.example.simpleweatherapp.data.local.Hour
import com.example.simpleweatherapp.data.remote.atEndOfDay
import com.example.simpleweatherapp.data.repository.TemperatureUnit
import com.example.simpleweatherapp.data.repository.WindSpeedUnit
import com.example.simpleweatherapp.ui.addalarm.RepeatDay
import com.example.simpleweatherapp.ui.addalarm.RepeatDayAdapter
import com.example.simpleweatherapp.ui.alarms.AlertAdapter
import com.example.simpleweatherapp.ui.favourite.CityAdapter
import com.example.simpleweatherapp.ui.weather.DayAdapter
import com.example.simpleweatherapp.ui.weather.HourAdapter
import timber.log.Timber
import java.text.DateFormat
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.roundToInt

/**
 * Binding adapter used to display correct temperature
 */
@SuppressLint("SetTextI18n")
@BindingAdapter(value = ["temp", "temperatureUnit"], requireAll = false)
fun setTemp(view: TextView, temp: Float, temperatureUnit: TemperatureUnit?) {
    val nf = NumberFormat.getInstance(Locale.getDefault())
    //switch to determine current unit
    when (temperatureUnit) {
        TemperatureUnit.CELSIUS -> view.text =
            "${nf.format(temp.roundToInt())}${temperatureUnit.degreeSign}"
        TemperatureUnit.KELVIN -> view.text =
            "${nf.format(temperatureUnit.cToK(temp))}${temperatureUnit.degreeSign}"
        TemperatureUnit.FAHRENHEIT -> view.text =
            "${nf.format(temperatureUnit.cToF(temp))}${temperatureUnit.degreeSign}"
    }


}

@BindingAdapter("dateTime")
fun setDateTime(textView: TextView, date: Long) {
    if (date != 0L)
        textView.text = DateFormat.getTimeInstance(DateFormat.SHORT).format(date)
}

@BindingAdapter("lastUpdate")
fun setLastUpdate(textView: TextView, date: Long) {
    if (date != 0L)
        textView.text =
            DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.SHORT).format(date)
}

@BindingAdapter("alarmType")
fun setAlarmType(image: ImageView, type: String?) {
    if (type == image.resources.getString(R.string.notification_type))
        image.setImageResource(R.drawable.ic_baseline_notifications_24)
    else
        image.setImageResource(R.drawable.ic_baseline_alarm_24)
}

@BindingAdapter("hourTime")
fun setHourTime(textView: TextView, date: Long) {
    if (date != 0L) {
        val endOfDay: Long = atEndOfDay(date)
        if (date < endOfDay) {
            textView.text =
                DateFormat.getTimeInstance(DateFormat.SHORT).format(date)
        } else {
            textView.text =
                SimpleDateFormat("hh:mm aa", Locale.getDefault()).format(date)
        }
    }
}

@BindingAdapter("dayDate")
fun setDayDate(textView: TextView, date: Long) {
    if (date != 0L) {
        textView.text =
            SimpleDateFormat("EEE, dd/M", Locale.getDefault()).format(date)
    }
}


@BindingAdapter("goneStatus")
fun setGone(view: View, status: Boolean) {
    if (status)
        view.visibility = View.GONE
}

@BindingAdapter(value = ["listDayData", "dayTemperatureUnit"], requireAll = false)
fun bindDayRecyclerView(
    recyclerView: RecyclerView,
    data: List<Day>?,
    dayTemperatureUnit: TemperatureUnit?
) {
    val adapter = recyclerView.adapter as DayAdapter
    adapter.temperatureUnit = dayTemperatureUnit
    adapter.submitList(data)
}

@BindingAdapter(value = ["listHourData", "hourTemperatureUnit"])
fun bindHourRecyclerView(
    recyclerView: RecyclerView,
    data: List<Hour>?,
    hourTemperatureUnit: TemperatureUnit?
) {
    val adapter = recyclerView.adapter as HourAdapter
    adapter.temperatureUnit = hourTemperatureUnit
    adapter.submitList(data)
}

@BindingAdapter("repeatDayList")
fun bindRepeatDayRecyclerView(recyclerView: RecyclerView, data: List<RepeatDay>?) {
    val adapter = recyclerView.adapter as RepeatDayAdapter
    if (data != null) {
        adapter.data = data
    }
}

@BindingAdapter("dayName")
fun bindRepeatDaysName(textView: TextView, index: Int) {
    val weekDays = getWeekDays()
    textView.text = weekDays[index]
}


@BindingAdapter(value = ["listFavouriteData", "favouriteTemperatureUnit"])
fun bindFavouriteRecyclerView(
    recyclerView: RecyclerView,
    data: List<City>?,
    favouriteTemperatureUnit: TemperatureUnit?
) {
    val adapter = recyclerView.adapter as CityAdapter
    adapter.temperatureUnit = favouriteTemperatureUnit
    adapter.submitList(data)
}

@BindingAdapter("listAlertData")
fun bindAlertRecyclerView(
    recyclerView: RecyclerView,
    data: List<Alarm>?
) {
    val adapter = recyclerView.adapter as AlertAdapter
    adapter.submitList(data)
}

@BindingAdapter("weatherIcon")
fun bindIcon(imgView: ImageView, img: String?) {
    Timber.i("weatherIcon string : $img")
    img?.let {
        when (img) {
            "01d" -> imgView.setImageResource(R.drawable._01d)
            "01n" -> imgView.setImageResource(R.drawable._01n)
            "02d" -> imgView.setImageResource(R.drawable._02d)
            "02n" -> imgView.setImageResource(R.drawable._02n)
            "03d", "03n" -> imgView.setImageResource(R.drawable._03)
            "04d", "04n" -> imgView.setImageResource(R.drawable._04)
            "09d", "09n" -> imgView.setImageResource(R.drawable._09)
            "10d" -> imgView.setImageResource(R.drawable._10d)
            "10n" -> imgView.setImageResource(R.drawable._10n)
            "11d", "11n" -> imgView.setImageResource(R.drawable._11)
            "13d", "13n" -> imgView.setImageResource(R.drawable._13)
            "50d", "50n" -> imgView.setImageResource(R.drawable._50)
        }
    }
}

