package com.example.simpleweatherapp.worker

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import androidx.core.content.ContextCompat
import androidx.lifecycle.asFlow
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.simpleweatherapp.R
import com.example.simpleweatherapp.data.local.getDatabase
import com.example.simpleweatherapp.data.repository.Repository
import com.example.simpleweatherapp.data.repository.TemperatureUnit
import com.example.simpleweatherapp.data.repository.UserPreferencesRepository
import com.example.simpleweatherapp.ui.alertdialog.DefaultSoundAlarm
import com.example.simpleweatherapp.utils.getCurrentDayIndex
import com.example.simpleweatherapp.utils.sendNotification
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import timber.log.Timber
import kotlin.math.roundToInt

const val ALARM_TITLE = "AlarmTitle"
const val ALARM_MESSAGE_BODY = "AlarmMessageBody"
const val ALARM_MESSAGE_DESCRIPTION = "AlarmMessageDescription"

class AlarmWorker(appContext: Context, params: WorkerParameters) :
    CoroutineWorker(appContext, params) {
    /**
     * A coroutine-friendly method to do your work.
     */


    private lateinit var title: String
    private lateinit var messageBody: String
    private var messageDescription: String? = null
    override suspend fun doWork(): Result {
        Timber.i("AlarmWorker Started")

        //get current day index and check if this day scheduled to shaw an alarm else fail
        //is scheduled then check the end time if exceed then fail
        //else complete work normal any other exception retry
        val currentDayIndex = getCurrentDayIndex()
        val mapAlarmRepeatable = inputData.keyValueMap
        if (!(mapAlarmRepeatable["$currentDayIndex"] as Boolean)) {
            //this day not scheduled to work in it
            //then fail
            Timber.i("mapAlarmRepeatable[\"$currentDayIndex\"] as Boolean : false")
            Timber.i("Then -> worker failure")
            return Result.failure()
        }
        Timber.i("mapAlarmRepeatable[\"$currentDayIndex\"] as Boolean : true")
        return try {
            val alarmType = inputData.getString(ALARM_TYPE) ?: return Result.failure()
            val alarmName = inputData.getString(ALARM_NAME) ?: return Result.failure()
            val alarmEndTime =
                inputData.getLong(ALARM_END_TIME, 0)

            //check if current time Exceeded the end time
            if (System.currentTimeMillis() > alarmEndTime) {
                Timber.i("current time Exceeded the end time that associated to worker!!!")
                Timber.i("Then -> worker failure")
                return Result.failure()
            }

            val repository = Repository(getDatabase(applicationContext))

            val userPreferencesRepository =
                UserPreferencesRepository.getInstance(applicationContext)

            val homeLocation = userPreferencesRepository.homeLocationLatLng.first()

            repository.fetchWeather(
                homeLocation.latitude.toFloat(),
                homeLocation.longitude.toFloat(),
                "en"
            )
            if (!repository.alerts.value.isNullOrEmpty()) {
                repository.alerts.value!!.forEach { alert ->
                    title = alert.event
                    messageBody = alert.sender_name
                    messageDescription = alert.description
                    fireNotificationOrAlarm(alarmType)
                    delay(AlertWorker.MINUTE_10)
                }
            } else {
                val temp = repository.weatherLiveData().asFlow().first().temp
                val temperatureUnit =
                    userPreferencesRepository.userPreferencesFlow.first().temperatureUnit
                title = alarmName
                messageBody =
                    when (temperatureUnit) {
                        TemperatureUnit.CELSIUS -> "No alerts every thing ok, ${temp.roundToInt()}${temperatureUnit.degreeSign}"
                        TemperatureUnit.KELVIN -> "No alerts every thing ok, ${
                            temperatureUnit.cToK(
                                temp
                            )
                        }${temperatureUnit.degreeSign}"
                        TemperatureUnit.FAHRENHEIT -> "No alerts every thing ok, ${
                            temperatureUnit.cToF(
                                temp
                            )
                        }${temperatureUnit.degreeSign}"
                    }
                fireNotificationOrAlarm(alarmType)
            }
            //work complete successfully
            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            //exception occurs then should be tried at another time according to its retry policy.
            Result.retry()
        }
    }

    private fun fireNotificationOrAlarm(alarmType: String) {
        //notification alarm
        if (alarmType == "notification") {
            // sendNotification
            val notificationManager = ContextCompat.getSystemService(
                applicationContext,
                NotificationManager::class.java
            ) as NotificationManager

            notificationManager.sendNotification(
                title,
                messageBody,
                messageDescription,
                applicationContext.getString(R.string.weather_alarms_channel_id),
                applicationContext
            )
        } else {
            val intent = Intent(applicationContext, DefaultSoundAlarm::class.java)
            intent.putExtra(ALARM_TITLE, title)
            intent.putExtra(ALARM_MESSAGE_BODY, messageBody)
            intent.putExtra(ALARM_MESSAGE_DESCRIPTION, messageDescription)
            intent.flags = FLAG_ACTIVITY_NEW_TASK;
            applicationContext.startActivity(intent)
        }
    }

    companion object {
        const val ALARM_TYPE = "AlarmType"
        const val ALARM_NAME = "AlarmName"
        const val ALARMS_TAG = "AlarmsTag"
        const val ALARM_END_TIME = "AlarmEndTime"
    }
}