package com.example.simpleweatherapp.ui.weather

import android.app.Application
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.NetworkInfo
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import com.example.simpleweatherapp.data.local.getDatabase
import com.example.simpleweatherapp.data.remote.Alerts
import com.example.simpleweatherapp.data.repository.Repository
import com.example.simpleweatherapp.data.repository.UserPreferencesRepository
import com.example.simpleweatherapp.utils.setAlertWorker
import com.example.simpleweatherapp.utils.setupRecurringWorkBuilder
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import timber.log.Timber
import kotlin.properties.Delegates

class WeatherViewModel(
    private val app: Application
) : AndroidViewModel(app) {

    private val userPreferencesRepository =
        UserPreferencesRepository.getInstance(app.applicationContext)

    val homeName = userPreferencesRepository.homeLocationName.asLiveData()

    val userPreferences = userPreferencesRepository.userPreferencesFlow.asLiveData()

    private var homeLocationLatLng: LatLng? = null

    private var alertsPreferences by Delegates.notNull<Boolean>()

    init {
        Timber.i("WeatherViewModel created")
    }

    private val database = getDatabase(app)
    private val repository = Repository(database)

    //Live Data of network error
    val networkRequest = repository.weatherApiStatus

    //Live Data of Main Weather Info
    val weather = repository.weatherLiveData()

    //Live Data of Weather days Info
    val dayList = repository.daysLiveData()

    //Live Data of Weather hours Info
    val hoursList = repository.hoursLiveData()

    //progressbar status
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean>
        get() = _isLoading

    private val _networkStatus = MutableLiveData(true)
    val networkStatus: LiveData<Boolean>
        get() = _networkStatus


    private fun updateWeather() {
        viewModelScope.launch {
            if (homeLocationLatLng == null) {
                alertsPreferences = userPreferencesRepository.weatherAlertsFlow.first()
                homeLocationLatLng = userPreferencesRepository.homeLocationLatLng.first()
                Timber.i("Lat : ${homeLocationLatLng!!.latitude}")
                Timber.i("lng : ${homeLocationLatLng!!.longitude}")
            }
            repository.fetchWeather(
                homeLocationLatLng!!.latitude.toFloat(),
                homeLocationLatLng!!.longitude.toFloat(),
                userPreferences.value?.lang!!
            )
            setAlerts()
        }
        _isLoading.value = false
    }

    private fun setAlerts() {
        viewModelScope.launch {
            if (alertsPreferences) {
                Timber.i("alertsPreferences true")
                //receive alerts and add it to work manager
                if (!repository.alerts.value.isNullOrEmpty()) {
                    Timber.i("repository.alerts.value.isNullOrEmpty")
                    withContext(Dispatchers.IO) {
                        repository.alerts.value!!.forEach { alert ->
                            addAlertWorkManager(alert)
                        }
                    }
                } else {
                    Timber.i("repository alerts is null")
                    addAlertWorkManager(
                        Alerts(
                            "NWS Tulsa (Eastern Oklahoma)",
                            "Heat Advisory",
                            1613656610,
                            0,
                            "...HEAT ADVISORY REMAINS IN EFFECT FROM 1 PM THIS AFTERNOON TO\n8 PM CDT THIS EVENING...\n* WHAT...Heat index values of 105 to 109 degrees expected.\n* WHERE...Creek, Okfuskee, Okmulgee, McIntosh, Pittsburg,\nLatimer, Pushmataha, and Choctaw Counties.\n* WHEN...From 1 PM to 8 PM CDT Thursday.\n* IMPACTS...The combination of hot temperatures and high\nhumidity will combine to create a dangerous situation in which\nheat illnesses are possible."
                        )
                    )
                }
            }

        }
    }

    private fun addAlertWorkManager(alert: Alerts) {
        val builder = setupRecurringWorkBuilder(alert)
        setAlertWorker(app, builder, "${alert.event}_${alert.sender_name}")
    }


    fun fetchWeatherAction() {
        _isLoading.value = true
        if (isNetworkConnected()) {
            Timber.i("Network Source Found")
            _networkStatus.value = true
            updateWeather()
        } else {
            Timber.i("No Network Source Found")
            _networkStatus.value = false
            _isLoading.value = false
        }
    }


    private fun isNetworkConnected(): Boolean {
        val connectivityManager = ContextCompat.getSystemService(
            app,
            ConnectivityManager::class.java
        ) as ConnectivityManager
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val activeNetwork = connectivityManager.activeNetwork
            val networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
            networkCapabilities != null &&
                    networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } else {
            val activeNetwork: NetworkInfo? = connectivityManager.activeNetworkInfo
            activeNetwork?.isConnectedOrConnecting == true
        }
    }


    fun clearStatus() {
        repository.changeWeatherRequestStatus()
    }


    override fun onCleared() {
        super.onCleared()
        Timber.i("WeatherViewModel Cleared")
    }
}
