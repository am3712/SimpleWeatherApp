package com.example.simpleweatherapp.data.remote

import com.google.gson.annotations.SerializedName

data class Snow(

    @SerializedName("1h") val _1h: Double
)