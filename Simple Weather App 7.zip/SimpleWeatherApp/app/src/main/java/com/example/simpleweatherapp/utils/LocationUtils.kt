package com.example.simpleweatherapp.utils

import android.annotation.SuppressLint
import android.location.Address
import android.location.Geocoder
import android.os.Looper
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import java.io.IOException
import java.text.DecimalFormat


fun getRoundedNum(num: Double): Float {
    val df = DecimalFormat("#.####")
    return df.format(num).toFloat()
}

fun getLocationName(geoCoder: Geocoder, lat: Double?, lng: Double?): String? {
    return try {
        lat?.let { latitude ->
            lng?.let { longitude ->
                val addressList: MutableList<Address> =
                    geoCoder.getFromLocation(latitude, longitude, 1)
                if (!addressList.isNullOrEmpty())
                    addressList[0].getAddressLine(0)
                else
                    null
            }
        }
    } catch (e: IOException) {
        e.printStackTrace()
        null
    }
}

class LocationUpdatesUseCase(private val client: FusedLocationProviderClient) {

    @SuppressLint("MissingPermission")
    fun fetchUpdates(): Flow<LatLng> = callbackFlow {

        val callBack = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                val location = locationResult.locations[0]
                val userLocation = LatLng(
                    location.latitude,
                    location.longitude
                )
                try {
                    offer(userLocation)
                } catch (t: Throwable) {
                    offer(null)
                }

            }
        }
        client.requestLocationUpdates(locationRequest, callBack, Looper.getMainLooper())
        awaitClose { client.removeLocationUpdates(callBack) }
    }

    companion object {
        private val locationRequest = LocationRequest().apply {
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }
    }
}